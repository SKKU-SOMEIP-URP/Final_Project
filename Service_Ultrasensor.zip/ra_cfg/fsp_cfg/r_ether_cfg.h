/* generated configuration header file - do not edit */
#ifndef R_ETHER_CFG_H_
#define R_ETHER_CFG_H_
#define ETHER_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define ETHER_CFG_LINK_PRESENT (0)
#define ETHER_CFG_USE_LINKSTA (0)
#endif /* R_ETHER_CFG_H_ */
