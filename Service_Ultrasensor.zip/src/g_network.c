#include <g_network.h>
#include <hal_data.h>

uint8_t isNetworkUp(void)
{
    fsp_err_t  eth_link_status = FSP_ERR_NOT_OPEN;
    uint8_t networkUp = 0;
    uint32_t network_status = (IP_LINK_UP | ETHERNET_LINK_UP);

    //networkUp = FreeRTOS_IsNetworkUp();
    networkUp = true;
    eth_link_status = R_ETHER_LinkProcess(g_ether0.p_ctrl);

    if((FSP_SUCCESS == eth_link_status) && (1 == networkUp))
    {
        return network_status;
    }
    else
    {
        if(FSP_SUCCESS != eth_link_status)
        {
            network_status |= ETHERNET_LINK_DOWN;
        }
        else if(FSP_SUCCESS == eth_link_status)
        {
            network_status |= ETHERNET_LINK_UP;
        }

        if(0 == networkUp)
        {
             network_status |= IP_LINK_DOWN;
        }
        else if(1 == networkUp)
        {
             network_status |= IP_LINK_UP;
        }
        return network_status;
    }
}