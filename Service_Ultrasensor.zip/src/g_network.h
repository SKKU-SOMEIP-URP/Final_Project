#include <hal_data.h>

#ifndef G_NETWORK_LIB_H_
#define G_NETWORK_LIB_H_

/* PREDEFINED VALUE FOR NETWORK STATE */
#define ETHERNET_LINK_DOWN 0x01
#define ETHERNET_LINK_UP 0x00
#define IP_LINK_DOWN 0x02
#define IP_LINK_UP 0x00

uint8_t isNetworkUp();

#endif 