# include <FND.h>


void Segments_Write(int num);
void Segment_Write(int seg_data, int seg_digit);
int data=0;
uint16_t get_service_id = 0;

void Segments_Write(int num)
{
    int SEG_Num[4] = {0, 0, 0, 0};

    if (num < 0)
    {
        SEG_Num[0] = 0;
        SEG_Num[1] = 0;
        SEG_Num[2] = 0;
        SEG_Num[3] = 0;
    }
    else
    {
        SEG_Num[0] = num / 1000;
        SEG_Num[1] = num / 100;
        SEG_Num[2] = (num % 100) / 10;
        SEG_Num[3] = num % 10;
    }

    if (SEG_Num[0] == 0 && SEG_Num[1] == 0)
    {
        for (int i = 2; i < 4; i++)
        {
            Segment_Write(SEG[SEG_Num[i]], i + 1);
            R_BSP_SoftwareDelay(100, BSP_DELAY_UNITS_MICROSECONDS);
        }
    }
    else if (SEG_Num[0] == 0)
    {
        for (int i = 1; i < 4; i++)
        {
            Segment_Write(SEG[SEG_Num[i]], i + 1);
            R_BSP_SoftwareDelay(100, BSP_DELAY_UNITS_MICROSECONDS);
        }
    }
    else
    {
        for (int i = 0; i < 4; i++)
        {
            Segment_Write(SEG[SEG_Num[i]], i + 1);
            R_BSP_SoftwareDelay(100, BSP_DELAY_UNITS_MICROSECONDS);
        }
    }
}

void Segment_Write(int seg_data, int seg_digit)
{
    if (seg_digit != 0)
    {
        R_IOPORT_PortWrite(&g_ioport_ctrl, BSP_IO_PORT_03, (ioport_size_t)(0x0010 << seg_digit), (ioport_size_t)0x01E0);
        R_IOPORT_PortWrite(&g_ioport_ctrl, BSP_IO_PORT_06, (ioport_size_t)((((~seg_data) & 0x0f) << 4) | (((~seg_data) & 0xf0) << 7)), (ioport_size_t)0x78f0);
    }
}

void FND_write(ethFrameStr *Msg)
{   
    get_service_id = xGetServiceID(Msg);

    // //gui 테스트용 
    // if (Msg->Service_ID == (16) && Msg->Message_Type == REQUEST){ 
    //     data = Msg->Payload[0];
    // }

    //정상 코드
    if (get_service_id == ULTRASOUND_SERVICE_ID && Msg->Message_Type == NOTIFICATION){
        data = Msg->Payload[0];
    }
    
    Segments_Write(data);
}