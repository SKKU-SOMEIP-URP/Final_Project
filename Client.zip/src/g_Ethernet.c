#include <g_Ethernet.h>
#include <someip_sd.h>
#include <Servo.h>

extern uint8_t sourceMAC[ETH_MAC_ADDR_SIZE];      // Source MAC Address
extern uint8_t sourceIP[ETH_IP_ADDR_SIZE];        // Source IP Address
extern uint8_t destinationMAC[ETH_MAC_ADDR_SIZE]; // Destination MAC Address
extern uint8_t destinationIP[ETH_IP_ADDR_SIZE];   // Destination IP Address

// 필요한 변수
extern int distance;
extern uint8_t ECU;

uint8_t angle;

void R_Eth_Initial_Setting()
{
    fsp_err_t err = FSP_SUCCESS;

    R_ETHER_Open(&g_ether0_ctrl, &g_ether0_cfg);
    R_ETHERC_EDMAC->EESIPR_b.TCIP = 0U; // Disable Transmit Interrupt Setting

    do
    {
        err = R_ETHER_LinkProcess(&g_ether0_ctrl);
    } while (FSP_SUCCESS != err);
}

uint16_t calChecksum(ethFrameStr *Msg)
{
    uint16_t *ptr = NULL;
    uint32_t checksum = 0;

    for (uint8_t idx = 0; idx < ETH_IP_HEADER_SIZE / 2; idx++)
    {
        ptr = (uint16_t *)(Msg->dstMAC + ETH_MAC_HEAD_SIZE + (idx * IP_CHECKSUM_UNIT));
        checksum += (uint16_t)(*ptr << STRUCT_SHIFT_SIZE) | (uint16_t)(*ptr >> STRUCT_SHIFT_SIZE); // Consider Little Endian Format of Register
    }

    checksum = ~((checksum & FULL_MASK_16BIT) + checksum / IP_CHECKSUM_DIV);

    return (uint16_t)checksum;
}

eth_ip_checksum verChecksum(ethFrameStr *Msg)
{
    uint16_t *ptr = NULL;
    uint32_t checksum = 0;

    for (uint8_t idx = 0; idx < ETH_IP_HEADER_SIZE / 2; idx++)
    {
        ptr = (uint16_t *)(Msg->dstMAC + ETH_MAC_HEAD_SIZE + (idx * IP_CHECKSUM_UNIT));
        checksum += (uint16_t)(*ptr << STRUCT_SHIFT_SIZE) | (uint16_t)(*ptr >> STRUCT_SHIFT_SIZE); // Consider Little Endian Format of Register
    }

    checksum = ~(checksum + checksum / IP_CHECKSUM_DIV);

    if ((checksum & FULL_MASK_16BIT) == 0)
        return correct_checksum;
    else
        return wrong_checksum;
}

void setLayer2(ethFrameStr *Msg, uint8_t *dMAC, uint8_t *sMAC)
{
    // Ethernet Frame Destination & Source MAC Address Setting //
    memcpy(&Msg->dstMAC[0], dMAC, ETH_MAC_ADDR_SIZE);
    memcpy(&Msg->srcMAC[0], sMAC, ETH_MAC_ADDR_SIZE);

    // Ethernet Frame Type & Length Setting: IPv4 [0x0800] //
    Msg->ethType[0] = (uint8_t)(ETH_IPv4_TYPE >> STRUCT_SHIFT_SIZE); // Ethernet Frame Type: IPv4 [0x0800]
    Msg->ethType[1] = (uint8_t)(ETH_IPv4_TYPE & FULL_MASK_8BIT);
}

void setLayer3(ethFrameStr *Msg, uint8_t *dIP, uint8_t *sIP)
{
    // Ethernet Packet IP Header Setting //
    Msg->IPV = ETH_IPV_IPv4;   // 0b0100
    Msg->IHL = ETH_IHL_5;      // 0b0101
    Msg->DSCP = ETH_DSCP_INIT; // 0b000000
    Msg->ECN = ETH_ECN_INIT;   // 0b00

    Msg->TotalLen[0] = 0;
    Msg->TotalLen[1] = 0x2D; // layer3 이후 부터 payload 1B까지의 길이 (some/ip sd도 고려해야됨)

    Msg->GroupID[0] = ETH_IP_GID >> STRUCT_SHIFT_SIZE; // Group ID: 0x0001
    Msg->GroupID[1] = ETH_IP_GID & FULL_MASK_8BIT;

    Msg->fragInfo[0] = ETH_NonFrag | (ETH_FragOffset >> STRUCT_SHIFT_SIZE); // Non-Fragmentation & Fragmentation Offset: 0x0000
    Msg->fragInfo[1] = ETH_FragOffset & FULL_MASK_8BIT;

    Msg->TTL = ETH_TTL_INIT;      // Time to Live: 0x40
    Msg->Protocol = ETH_UDP_PROT; // Protocol: UDP [0x11]

    // Ethernet Packet Destination & Source IP Address Setting //
    memcpy(&Msg->dstIP[0], dIP, ETH_IP_ADDR_SIZE);
    memcpy(&Msg->srcIP[0], sIP, ETH_IP_ADDR_SIZE);

    uint16_t checksum = calChecksum(Msg);

    Msg->ICS[0] = (uint8_t)(checksum >> STRUCT_SHIFT_SIZE); // IP Checksum Setting
    Msg->ICS[1] = (uint8_t)(checksum & FULL_MASK_8BIT);

    memset(Msg->Payload, 0, sizeof(Msg->Payload));
}

void setLayer4(ethFrameStr *Msg, uint16_t dPort, uint16_t sPort) // UDP Header Setting
{
    Msg->srcPort = swap_uint16(sPort);
    Msg->dstPort = swap_uint16(dPort);

    Msg->UDP_Len[0] = 0;
    Msg->UDP_Len[1] = 0x19; // layer4 이후 부터 payload 1B까지의 길이 (some/ip sd도 고려해야됨)

    Msg->UDP_Checksum[0] = 0;
    Msg->UDP_Checksum[1] = 0;
}

void setLayer5(ethFrameStr *Msg)
{                                                  // SOME/IP Header Setting
    Msg->Service_ID = swap_uint16(ETH_SERVICE_ID); // SOME/IP Service ID

    Msg->Method_ID = swap_uint16(ETH_METHOD_ID); // SOME/IP Method ID

    Msg->SOMEIP_Length[3] = (0x09); // client id 이후 부터 payload 1B까지의 길이 (some/ip sd도 고려해야됨)

    Msg->Client_ID = swap_uint16(ETH_CLIENT_ID); // SOME/IP Client ID

    Msg->Session_ID = swap_uint16(ETH_SESSION_ID); // SOME/IP Session ID

    Msg->Protocol_Version = ETH_PROTOCOL_VERSION; // SOME/IP Protocol Version

    Msg->Interface_Version = ETH_INTERFACE_VERSION; // SOME/IP Interface Version

    Msg->Message_Type = ETH_MESSAGE_TYPE; // SOME/IP Message Type

    Msg->Return_Code = ETH_RETURN_CODE; // SOME/IP Return Code
}

void setLayer7(ethFrameStr *Msg, uint8_t data)
{
    Msg->Payload[0] = data;
}

void setEthFrame(ethFrameStr *Msg, uint8_t *dMAC, uint8_t *sMAC, uint8_t *dIP, uint8_t *sIP, uint8_t data)
{
    memset(Msg, 0, sizeof(ethFrameStr));
    setLayer2(Msg, dMAC, sMAC);
    setLayer3(Msg, dIP, sIP);
    setLayer4(Msg, 30509, 30509); // some/ip: 30490, some/ip sd: 30509
    setLayer5(Msg);
    setLayer7(Msg, data);
}

int Verify_RxFrameBuffer(ethFrameStr *RxFrameBuffer, ethFrameStr *RxFrameBuffer_verified)
{
    memcpy(RxFrameBuffer_verified, RxFrameBuffer, sizeof(ethFrameStr));

    memcpy(destinationMAC, RxFrameBuffer_verified->srcMAC, sizeof(destinationMAC));
    memcpy(destinationIP, RxFrameBuffer_verified->srcIP, sizeof(destinationIP));
    return 1;
}

void sendUltrasonicMsg(ethFrameStr *Msg, uint8_t data)
{
    setEthFrame(Msg, destinationMAC, sourceMAC, destinationIP, sourceIP, data);
    vSetServiceID(Msg, ULTRASOUND_SERVICE_ID);
    vSetMessageType(Msg, NOTIFICATION);

    if (!isNetworkUp())
    {
        R_ETHER_Write(&g_ether0_ctrl, Msg, 59);
        R_BSP_SoftwareDelay(96, BSP_DELAY_UNITS_MICROSECONDS);
    }
}

void sendReplyMsg(ethFrameStr *RxMsg, ethFrameStr *TxMsg)
{
    memset(TxMsg, 0, sizeof(ethFrameStr));
    uint16_t SDService = xGetSD_ServiceID(RxMsg);

    switch (SDService)
    {
    case ULTRASOUND_SERVICE_ID: // 초음파 service가 subscribe msg를 받은 상황
        if (ECU)
            sendUltrasonicMsg(TxMsg, distance);
        break;

    case MOTOR_SERVICE_ID: // 모터 service가 subscribe msg를 받은 상황
        if (!ECU)
        {
            angle = ADC_Read_and_Convert();
            sendServoMotorMsg(TxMsg, angle);
        }
        break;
    default:
        break;
    }
}

uint16_t xGetServiceID(ethFrameStr *Msg)
{
    return swap_uint16(Msg->Service_ID);
}

void sendServoMotorMsg(ethFrameStr *TxMsg, uint8_t TxAngle)
{
    setEthFrame(TxMsg, destinationMAC, sourceMAC, destinationIP, sourceIP, TxAngle);
    vSetServiceID(TxMsg, MOTOR_SERVICE_ID);
    vSetMessageType(TxMsg, REQUEST_NO_RETURN);

    if (!isNetworkUp())
    {
        R_ETHER_Write(&g_ether0_ctrl, TxMsg, 59);
        R_BSP_SoftwareDelay(96, BSP_DELAY_UNITS_MICROSECONDS);
    }
}
