#ifndef G_ENDIAN_H_
#define G_ENDIAN_H_

#include <hal_data.h>
/** uint16 Swap Function **/
// uint16 endianess swap
uint16_t swap_uint16(uint16_t val);
/** uint32 endianess swap **/
uint32_t swap_uint32(uint32_t val);

#endif /* G_ENDIAN_H_ */
