#include <someip_sd.h>
#include <g_Ethernet.h>
#include <g_endian.h>

extern uint8_t sourceMAC[ETH_MAC_ADDR_SIZE];      // Source MAC Address
extern uint8_t sourceIP[ETH_IP_ADDR_SIZE];        // Source IP Address
extern uint8_t destinationMAC[ETH_MAC_ADDR_SIZE]; // Destination MAC Address
extern uint8_t destinationIP[ETH_IP_ADDR_SIZE];   // Destination IP Address
extern uint16_t SDServiceID;
extern uint8_t ECU;


uint8_t type;
uint8_t SD_Tx = 0;
uint8_t SD_Offer_Tx = 1;
uint8_t msg_length = 98;
uint8_t subscribe = 1; // client가 subscribe 했는지 확인하는 flag
uint16_t recSDService = 0xFFFF;

uint8_t multicastIP[ETH_IP_ADDR_SIZE] = {224, 0, 0, 0};
uint8_t multicastMAC[ETH_MAC_ADDR_SIZE] = {0x01, 0x00, 0x5E, 0x00, 0x00, 0x00};


void TransTask_SD_Offer(ethFrameStr *Msg, uint16_t Service_ID)
{
    vMakeOfferMsg(Msg, Service_ID);

    while (1)
    {
        if (SD_Offer_Tx && !isNetworkUp()) // network가 연결되어 있을 때만 전송
        {
            R_ETHER_Write(&g_ether0_ctrl, Msg, 98);
            R_BSP_SoftwareDelay(96, BSP_DELAY_UNITS_MICROSECONDS);
        }
        R_BSP_SoftwareDelay(2, BSP_DELAY_UNITS_SECONDS);
    }
}

void RecvTask_SD(ethFrameStr *RxMsg, ethFrameStr *TxMsg)
{
    memset(TxMsg, 0, sizeof(ethFrameStr));

    recSDService = xGetSD_ServiceID(RxMsg); // sd entry안에 있는 service id 추출

    if (RxMsg->Payload[0] == SD_FLAGS_OFFER && !ECU) // flag:0x80 = offer, client일 때
    {
        SDServiceID = recSDService;
        type = RxMsg->Payload[0 + SD_FLAGS_SIZE + SD_LENGTH_ARRAY_SIZE];
        if (type == 0x01 && subscribe) // type=0x01 = offer  && subscribe
        {
            vMakeSubMsg(TxMsg); // offer를 받으면 subscribe 보냄.

            msg_length = 98;
            SD_Tx = 1;
        }
        else // some/ip 메시지에서 우연히 offer가 아닌 다른 메시지가 들어온 경우 or subscribe 안함
        {
            SD_Tx = 0;
            // 오류처리
        }
    }
    // 자기 service id일때만 진행  28
    else if (RxMsg->Payload[0] == SD_FLAGS_SUBSCRIBE && recSDService == SDServiceID) // 0x00 = sub, suback, stopsub
    {
        type = RxMsg->Payload[0 + SD_FLAGS_SIZE + SD_LENGTH_ARRAY_SIZE];
        switch (type) // type
        {
        case SD_TYPE_SUBSCRIBE: // 0x06
            msg_length = 98;
            if (RxMsg->Payload[0 + 19] != 0) // TTL chcek, 0이 아니면 subscribe 수신받은 거임
            {
                vMakeSubAckMsg(TxMsg);
                sendReplyMsg(RxMsg, TxMsg);

                SD_Tx = 0; // vMakeSubAckMsg 내부에서 sd메시지 전송함
                break;
            }
            else // TTL이 0이면 client가 stop subcribe하는 거임
            {
                // subscribe = 0; // client가 subscribe 안했음을 표시
                SD_Tx = 0;
                break;
            }
        case SD_TYPE_SUBSCRIBE_ACK: // 0x07
            // client->service: some/ip msg 전송 
            // 가변저항 값을 전달하여 service의 서보모터 동작 시키기.
            sendReplyMsg(RxMsg, TxMsg);

            SD_Tx = 0; // sd메시지 전송 안함
            break;
        default:
            SD_Tx = 0;
            break;
        }
    }
    else
    { // sd 메시지가 아닌 경우
        SD_Tx = 0;
        //  오류처리
    }

    if (SD_Tx && !isNetworkUp())
    {
        R_ETHER_Write(&g_ether0_ctrl, TxMsg, msg_length);
        R_BSP_SoftwareDelay(96, BSP_DELAY_UNITS_MICROSECONDS);
    }
    SD_Tx = 0;

    return;
}

void vMakeOfferMsg(ethFrameStr *Msg, uint16_t Service_ID)
{
    memset(Msg, 0, sizeof(ethFrameStr));

    vSetSD_Header(Msg);
    memcpy(Msg->dstMAC, multicastMAC, sizeof(multicastMAC));
    memcpy(Msg->dstIP, multicastIP, sizeof(multicastIP));
    vSetSD_Flags(Msg, SD_FLAGS_OFFER); // 0x80

    uint32_t Length_Entry = swap_uint32(SD_ENTRY_SIZE * 1);
    memcpy(&(Msg->Payload[0 + SD_FLAGS_SIZE]), &Length_Entry, SD_LENGTH_ARRAY_SIZE);

    SD_ServiceEntry Entries[2];
    memset(Entries, 0, sizeof(SD_ServiceEntry) * 1);
    /* SOME/IP-SD Entries Setting */ // size = 32
    // Entry0 => Offer = 0x01, ServiceID = 0x0001 => Potentiometer
    Entries[0].Type = SD_TYPE_OFFER;
    Entries[0].OptionNum1st = 1;
    Entries[0].OptionNum2nd = 0;
    Entries[0].ServiceID = swap_uint16(Service_ID);
    Entries[0].InstanceID = swap_uint16(0x0001);
    Entries[0].MajorVer = 1;
    Entries[0].TTL[2] = 0xFF;
    Entries[0].TTL[1] = 0xFF;
    Entries[0].TTL[0] = 0xFF;
    Entries[0].MinorVer = 0;
    vAppendSD_ServiceEntry(Msg, Entries[0], 0);

    // // Entry1 => Offer = 0x01
    // Entries[1].Type = SD_TYPE_OFFER;
    // Entries[1].OptionNum1st = 0;
    // Entries[1].OptionNum2nd = 1;
    // Entries[1].ServiceID = swap_uint16(Service_ID);
    // Entries[1].InstanceID = swap_uint16(0x0001);
    // Entries[1].MajorVer = 1;
    // Entries[1].TTL[2] = 0xFF;
    // Entries[1].TTL[1] = 0xFF;
    // Entries[1].TTL[0] = 0xFF;
    // Entries[1].MinorVer = 0;
    // vAppendSD_ServiceEntry(Msg, Entries[1], 1);

    /* SOME/IP-SD IPv4 Option Setting */ // size = 0x0C
    SD_IPv4EndpntOption Option;
    memset(&Option, 0, sizeof(SD_IPv4EndpntOption));
    Length_Entry = swap_uint32(SD_IPv4_ENDPOINT_SIZE);
    memcpy(&(Msg->Payload[0 + SD_FLAGS_SIZE + SD_LENGTH_ARRAY_SIZE + SD_ENTRY_SIZE * 1]), &Length_Entry, 4);

    Option.Length = swap_uint16(SD_IPv4_ENDPOINT_LENGTH);
    Option.Type = 0x04;
    Option.Reserved_1 = 0x10;
    memcpy(Option.IPv4Addr, destinationIP, ETH_IP_ADDR_SIZE);
    Option.Reserved_2 = 0x01;
    Option.L4_Proto = 0x11;
    Option.Port_Number = swap_uint16(30509);

    vAppendSD_IPv4EndpntOption(Msg, Option, 0);

    vSetLength(Msg, SD_FLAGS_SIZE + SD_LENGTH_ARRAY_SIZE + SD_ENTRY_SIZE + SD_LENGTH_ARRAY_SIZE + SD_IPv4_ENDPOINT_SIZE);
    return;
}

void vMakeSubMsg(ethFrameStr *Msg)
{
    memset(Msg, 0, sizeof(ethFrameStr));

    vSetSD_Header(Msg);
    Msg->GroupID[0] = 0x01 >> STRUCT_SHIFT_SIZE; // Group ID: 0x0001
    Msg->GroupID[1] = 0x01 & FULL_MASK_8BIT;
    Msg->TTL = 0x40; // sub, stopsub
    vSetClientID(Msg, 0);
    vSetSessionID(Msg, 0);

    vSetSD_Flags(Msg, SD_FLAGS_SUBSCRIBE); // 0x00

    uint32_t Length_Entry = swap_uint32(SD_ENTRY_SIZE * 1); // 0x00000020
    memcpy(&(Msg->Payload[0 + SD_FLAGS_SIZE]), &Length_Entry, SD_LENGTH_ARRAY_SIZE);

    SD_EventGroupEntry Entries[2];
    memset(Entries, 0, sizeof(SD_EventGroupEntry) * 1);
    Entries[0].Type = SD_TYPE_SUBSCRIBE; // 0x06
    Entries[0].OptionNum1st = 0;
    Entries[0].OptionNum2nd = 1;
    Entries[0].ServiceID = swap_uint16(recSDService);
    Entries[0].InstanceID = swap_uint16(0x0001);
    Entries[0].MajorVer = 3;
    Entries[0].TTL[2] = 5;
    Entries[0].Counter = 0;
    Entries[0].EventgroupID = swap_uint16(0x0004);
    vAppendSD_EventGroupEntry(Msg, Entries[0], 0);

    // Entries[1].Type = SD_TYPE_SUBSCRIBE; // 0x06
    // Entries[1].OptionNum1st = 1;
    // Entries[1].OptionNum2nd = 0;
    // Entries[1].ServiceID = swap_uint16(recSDService);
    // Entries[1].InstanceID = swap_uint16(0x0001);
    // Entries[1].MajorVer = 3;
    // Entries[1].TTL[2] = 5;
    // Entries[1].Counter = 0;
    // Entries[1].EventgroupID = swap_uint16(0x0004);
    // vAppendSD_EventGroupEntry(Msg, Entries[1], 1);

    /* SOME/IP-SD IPv4 Option Setting */ // size = 0x0C
    SD_IPv4EndpntOption Option;
    memset(&Option, 0, sizeof(SD_IPv4EndpntOption));
    Length_Entry = swap_uint32(SD_IPv4_ENDPOINT_SIZE);
    memcpy(&(Msg->Payload[0 + SD_FLAGS_SIZE + SD_LENGTH_ARRAY_SIZE + SD_ENTRY_SIZE * 1]), &Length_Entry, 4);

    Option.Length = swap_uint16(SD_IPv4_ENDPOINT_LENGTH);
    Option.Type = 0x04;
    Option.Reserved_1 = 0x00;
    memcpy(Option.IPv4Addr, destinationIP, ETH_IP_ADDR_SIZE);
    Option.Reserved_2 = 0x00;
    Option.L4_Proto = 0x11;
    Option.Port_Number = swap_uint16(30509);

    vAppendSD_IPv4EndpntOption(Msg, Option, 0);

    vSetLength(Msg, SD_FLAGS_SIZE + SD_LENGTH_ARRAY_SIZE + SD_ENTRY_SIZE + SD_LENGTH_ARRAY_SIZE + SD_IPv4_ENDPOINT_SIZE);
    return;
}

void vMakeSubAckMsg(ethFrameStr *Msg)
{
    memset(Msg, 0, sizeof(ethFrameStr));

    vSetSD_Header(Msg);
    Msg->TotalLen[0] = 0;
    Msg->TotalLen[1] = 0x48; // some/ip-sd suback
    Msg->UDP_Len[0] = 0;
    Msg->UDP_Len[1] = 0x34;                // layer4 이후 부터 payload 1B까지의 길이 (some/ip sd도 고려해야됨)
    vSetSD_Flags(Msg, SD_FLAGS_SUBSCRIBE); // 0x00

    uint32_t Length_Entry = swap_uint32(SD_ENTRY_SIZE * 1); // 0x00000020
    memcpy(&(Msg->Payload[0 + SD_FLAGS_SIZE]), &Length_Entry, SD_LENGTH_ARRAY_SIZE);

    SD_EventGroupEntry Entries[2];
    memset(Entries, 0, sizeof(SD_EventGroupEntry) * 1);
    Entries[0].Type = SD_TYPE_SUBSCRIBE_ACK;
    Entries[0].OptionIdx1st = 0; // 자료에는 1, wireshark에는 0임
    Entries[0].OptionIdx2nd = 0;
    Entries[0].ServiceID = swap_uint16(recSDService);
    Entries[0].InstanceID = swap_uint16(0x0001);
    Entries[0].MajorVer = 1;
    Entries[0].TTL[2] = 5;
    Entries[0].Counter = 0;
    Entries[0].EventgroupID = swap_uint16(0x0001);
    vAppendSD_EventGroupEntry(Msg, Entries[0], 0);

    // Entries[1].Type = SD_TYPE_SUBSCRIBE_ACK;
    // Entries[1].OptionIdx1st = 0;
    // Entries[1].OptionIdx2nd = 0;
    // Entries[1].ServiceID = swap_uint16(recSDService);
    // Entries[1].InstanceID = swap_uint16(0x0001);
    // Entries[1].MajorVer = 1;
    // Entries[1].TTL[2] = 5;
    // Entries[1].Counter = 0;
    // Entries[1].EventgroupID = swap_uint16(0x0001);
    // vAppendSD_EventGroupEntry(Msg, Entries[1], 1);

    vAppendSD_OptionLength(Msg, 0);

    vSetLength(Msg, SD_FLAGS_SIZE + SD_LENGTH_ARRAY_SIZE + SD_ENTRY_SIZE + SD_LENGTH_ARRAY_SIZE);

    if (!isNetworkUp())
    {
        R_ETHER_Write(&g_ether0_ctrl, Msg, 98);
        R_BSP_SoftwareDelay(96, BSP_DELAY_UNITS_MICROSECONDS);
    }

    return;
}

void vMakeStopSubMsg(ethFrameStr *Msg) // 수정필요 (안써서 수정안했음) entry 1개
{
    memset(Msg, 0, sizeof(ethFrameStr));
    vSetSD_Header(Msg);

    vSetSD_Flags(Msg, SD_FLAGS_SUBSCRIBE); // 0x00

    uint32_t Length_Entry = swap_uint32(SD_ENTRY_SIZE * 2); // 0x00000020
    memcpy(&(Msg->Payload[0 + SD_FLAGS_SIZE]), &Length_Entry, SD_LENGTH_ARRAY_SIZE);

    SD_EventGroupEntry Entries[2];
    memset(Entries, 0, sizeof(SD_EventGroupEntry) * 2);
    Entries[0].Type = SD_TYPE_SUBSCRIBE; // 0x06
    Entries[0].OptionNum1st = 1;
    Entries[0].OptionNum2nd = 0;
    Entries[0].ServiceID = swap_uint16(0x0001);
    Entries[0].InstanceID = swap_uint16(0x0001);
    Entries[0].MajorVer = 3;
    Entries[0].TTL[2] = 0;
    Entries[0].Counter = 0;
    Entries[0].EventgroupID = swap_uint16(0x0004);
    vAppendSD_EventGroupEntry(Msg, Entries[0], 0);

    Entries[1].Type = SD_TYPE_SUBSCRIBE; // 0x06
    Entries[1].OptionNum1st = 1;
    Entries[1].OptionNum2nd = 0;
    Entries[1].ServiceID = swap_uint16(0x0002);
    Entries[1].InstanceID = swap_uint16(0x0001);
    Entries[1].MajorVer = 3;
    Entries[1].TTL[2] = 0;
    Entries[1].Counter = 0;
    Entries[1].EventgroupID = swap_uint16(0x0004);
    vAppendSD_EventGroupEntry(Msg, Entries[1], 1);

    /* SOME/IP-SD IPv4 Option Setting */ // size = 0x0C
    SD_IPv4EndpntOption Option;
    memset(&Option, 0, sizeof(SD_IPv4EndpntOption));
    Length_Entry = swap_uint32(SD_IPv4_ENDPOINT_SIZE);
    memcpy(&(Msg->Payload[0 + SD_FLAGS_SIZE + SD_LENGTH_ARRAY_SIZE + SD_ENTRY_SIZE * 2]), &Length_Entry, 4);

    Option.Length = swap_uint16(SD_IPv4_ENDPOINT_LENGTH);
    Option.Type = 0x04;
    Option.Reserved_1 = 0x00;
    memcpy(Option.IPv4Addr, destinationIP, ETH_IP_ADDR_SIZE);
    Option.Reserved_2 = 0x00;
    Option.L4_Proto = 0x11;
    Option.Port_Number = swap_uint16(30509);
    vAppendSD_IPv4EndpntOption(Msg, Option, 0);

    vSetLength(Msg, SD_FLAGS_SIZE + SD_LENGTH_ARRAY_SIZE + SD_ENTRY_SIZE + SD_LENGTH_ARRAY_SIZE + SD_IPv4_ENDPOINT_SIZE);
    return;
}

void vSetSD_Flags(ethFrameStr *Msg, uint8_t Flags)
{
    memset(Msg->Payload, 0, SD_FLAGS_SIZE);
    memcpy(Msg->Payload, &Flags, sizeof(uint8_t));
    return;
}

void vAppendSD_IPv4EndpntOption(ethFrameStr *Msg, SD_IPv4EndpntOption Option, uint32_t Offset)
{
    uint32_t EntrySize = xGetSD_EntryLength(Msg);
    uint32_t StartIndex = SD_FLAGS_SIZE + SD_LENGTH_ARRAY_SIZE + EntrySize + SD_LENGTH_ARRAY_SIZE;
    memcpy(Msg->Payload + StartIndex + Offset * SD_IPv4_ENDPOINT_SIZE, &Option, SD_IPv4_ENDPOINT_SIZE);
    return;
}

void vAppendSD_ServiceEntry(ethFrameStr *Msg, SD_ServiceEntry Entry, uint32_t Offset)
{
    memcpy(Msg->Payload + SD_FLAGS_SIZE + SD_LENGTH_ARRAY_SIZE + Offset * SD_ENTRY_SIZE, &Entry, SD_ENTRY_SIZE);
    return;
}

void vAppendSD_EventGroupEntry(ethFrameStr *Msg, SD_EventGroupEntry Entry, uint32_t Offset)
{
    memcpy(Msg->Payload + SD_FLAGS_SIZE + SD_LENGTH_ARRAY_SIZE + Offset * SD_ENTRY_SIZE, &Entry, SD_ENTRY_SIZE);
    return;
}

uint32_t xGetSD_EntryLength(ethFrameStr *Msg)
{
    uint8_t arr[4] = {0};
    uint32_t ret = 0;
    /** 왜 안됨? **/
    //    memcpy(&ret, Msg->Total.Payload + SD_FLAGS_SIZE, SD_LENGTH_ARRAY_SIZE);

    memcpy(arr, Msg->Payload + SD_FLAGS_SIZE, SD_LENGTH_ARRAY_SIZE);
    ret |= arr[0] << 24;
    ret |= arr[1] << 16;
    ret |= arr[2] << 8;
    ret |= arr[3];
    return ret;
}

void vAppendSD_EventGroupLength(ethFrameStr *Msg, uint32_t Len)
{
    memcpy(Msg->Payload + SD_FLAGS_SIZE, &Len, SD_LENGTH_ARRAY_SIZE);

    return;
}

void vAppendSD_OptionLength(ethFrameStr *Msg, uint32_t Len)
{
    Len = swap_uint32(Len);
    uint32_t EntrySize = xGetSD_EntryLength(Msg);
    uint32_t StartIndex = SD_FLAGS_SIZE + SD_LENGTH_ARRAY_SIZE + EntrySize;
    memcpy(Msg->Payload + StartIndex, &Len, SD_LENGTH_ARRAY_SIZE);

    return;
}

void vSetLength(ethFrameStr *Msg, uint32_t val)
{
    // length = From Client ID to Return Code + Payload
    Msg->SOMEIP_Length[0] = (uint8_t)((val + 8) >> STRUCT_SHIFT_SIZE_24BIT);
    Msg->SOMEIP_Length[1] = (uint8_t)((val + 8) >> STRUCT_SHIFT_SIZE_16BIT);
    Msg->SOMEIP_Length[2] = (uint8_t)((val + 8) >> STRUCT_SHIFT_SIZE);
    Msg->SOMEIP_Length[3] = (uint8_t)((val + 8) & FULL_MASK_8BIT);
    return;
}

void vSetSD_Header(ethFrameStr *Msg)
{
    vSetLayer2_3_4(Msg); // 2,3,4 layer setting

    /** SOME/IP Header **/
    vSetServiceID(Msg, 0xFFFF);
    vSetMethodID(Msg, SD_METHOD_ID);
    vSetClientID(Msg, ECU_CLIENT_ID);
    vSetSessionID(Msg, SD_SESSION_ID);
    vSetProtocolVersion(Msg);
    vSetInterfaceVersion(Msg);
    vSetMessageType(Msg, NOTIFICATION);
    vSetReturnCode(Msg, E_OK);

    return;
}

void vSetLayer2_3_4(ethFrameStr *Msg)
{
    /** Layer 2 **/
    memcpy(Msg->dstMAC, destinationMAC, ETH_MAC_ADDR_SIZE);          // Destination MAC Address
    memcpy(Msg->srcMAC, sourceMAC, ETH_MAC_ADDR_SIZE);               // Source MAC Address
    Msg->ethType[0] = (uint8_t)(ETH_IPv4_TYPE >> STRUCT_SHIFT_SIZE); // Ethernet Frame Type: IPv4 [0x0800]
    Msg->ethType[1] = (uint8_t)(ETH_IPv4_TYPE & FULL_MASK_8BIT);

    /** Layer 3 **/
    // Ethernet Packet IP Header Setting //
    Msg->IPV = ETH_IPV_IPv4;   // 0b0100
    Msg->IHL = ETH_IHL_5;      // 0b0101
    Msg->DSCP = ETH_DSCP_INIT; // 0b000000
    Msg->ECN = ETH_ECN_INIT;   // 0b00
    Msg->TotalLen[0] = 0;
    Msg->TotalLen[1] = 0x54;                     // some/ip-sd offer,sub
    Msg->GroupID[0] = 0x00 >> STRUCT_SHIFT_SIZE; // Group ID: 0x0000
    Msg->GroupID[1] = 0x00 & FULL_MASK_8BIT;
    Msg->fragInfo[0] = ETH_NonFrag | (ETH_FragOffset >> STRUCT_SHIFT_SIZE); // Non-Fragmentation & Fragmentation Offset: 0x0000
    Msg->fragInfo[1] = ETH_FragOffset & FULL_MASK_8BIT;
    Msg->TTL = 0x80;              // Time to Live: 0x80
    Msg->Protocol = ETH_UDP_PROT; // Protocol: UDP [0x11]
    // Ethernet Packet Destination & Source IP Address Setting //
    memcpy(Msg->dstIP, destinationIP, ETH_IP_ADDR_SIZE);
    memcpy(Msg->srcIP, sourceIP, ETH_IP_ADDR_SIZE);
    uint16_t checksum = calChecksum(Msg);
    Msg->ICS[0] = (uint8_t)(checksum >> STRUCT_SHIFT_SIZE); // IP Checksum Setting
    Msg->ICS[1] = (uint8_t)(checksum & FULL_MASK_8BIT);
    memset(Msg->Payload, 0, sizeof(Msg->Payload));

    /** Layer 4 **/
    Msg->srcPort = swap_uint16(30490);
    Msg->dstPort = swap_uint16(30490);
    Msg->UDP_Len[0] = 0;
    Msg->UDP_Len[1] = 0x40; // layer4 이후 부터 payload 1B까지의 길이 (some/ip sd도 고려해야됨)
    Msg->UDP_Checksum[0] = 0;
    Msg->UDP_Checksum[1] = 0;

    return;
}

void vSetServiceID(ethFrameStr *Msg, uint16_t val)
{
    Msg->Service_ID = swap_uint16(val);
    return;
}

void vSetMethodID(ethFrameStr *Msg, uint16_t val)
{
    Msg->Method_ID = swap_uint16(val);
    return;
}

void vSetClientID(ethFrameStr *Msg, uint16_t val)
{
    Msg->Client_ID = swap_uint16(val);
    return;
}

void vSetSessionID(ethFrameStr *Msg, uint16_t val)
{
    Msg->Session_ID = swap_uint16(val);
    return;
}

void vSetProtocolVersion(ethFrameStr *Msg)
{
    Msg->Protocol_Version = 0x01;
    return;
}
void vSetInterfaceVersion(ethFrameStr *Msg)
{
    Msg->Interface_Version = 0x01;
    return;
}
void vSetMessageType(ethFrameStr *Msg, uint8_t val)
{
    Msg->Message_Type = val;
    return;
}

void vSetReturnCode(ethFrameStr *Msg, uint8_t val)
{
    Msg->Return_Code = val;
    return;
}

void vSetPayload(ethFrameStr *Msg, uint8_t val)
{
    Msg->Payload[0] = val;
    return;
}

uint16_t xGetSD_ServiceID(ethFrameStr *RxMSg)
{
    uint16_t ret = 0;
    ret |= RxMSg->Payload[12] << 8;
    ret |= RxMSg->Payload[13];
    return ret;
}
