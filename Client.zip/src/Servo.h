#include <hal_data.h>
#include <g_Ethernet.h>
#include <someip_sd.h>
#ifndef SERVO_LIB_H_
#define SERVO_LIB_H_


void GPT_Setting();
void Rotate_Servo(ethFrameStr *Msg);
uint8_t ADC_Read_and_Convert();

#endif 