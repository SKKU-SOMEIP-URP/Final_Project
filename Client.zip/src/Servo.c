#include <Servo.h>

/* Variables about Motor */
double temp_calc = 0.0;
uint8_t degree = 0;
uint32_t Timer_Period = 0x249F00; // 20[ms] Duty Cycle (50[Hz])
const double SERVO_MINIMUM_DUTY = 0.03;
const double SERVO_MAXIMUM_DUTY = 0.12;
const double SERVO_EACH_DEGREE = (SERVO_MAXIMUM_DUTY - SERVO_MINIMUM_DUTY) / 180;
uint16_t motor_service_id = 0;

/* Variables about ADC */
const float ADC_CONST = (float)(3.3 / 4096);
uint16_t potentiometer_mV = 0, potentiometer_Ra = 0, potentiometer_Rb = 0;
const float Ret_to_motor_rate = (float)(180 / 10000); // rate for resistor to motor angle
uint16_t received_resist;
uint8_t temp_degree;

uint8_t ADC_Read_and_Convert()
{
    adc_status_t status;
    uint8_t return_angle = 0;

    R_ADC_ScanStart(&g_adc0_ctrl);

    status.state = ADC_STATE_SCAN_IN_PROGRESS;
    while (ADC_STATE_SCAN_IN_PROGRESS == status.state)
    {
        R_ADC_StatusGet(&g_adc0_ctrl, &status);
    }

    uint16_t ch0_adc_result;

    R_ADC_Read(&g_adc0_ctrl, ADC_CHANNEL_0, &ch0_adc_result);
    potentiometer_mV = (uint16_t)(ch0_adc_result * ADC_CONST * 1000);
    potentiometer_Rb = (uint16_t)(potentiometer_mV * 3.0303);
    potentiometer_Ra = (uint16_t)(10000 - potentiometer_Rb);

    return_angle = (uint8_t)(potentiometer_Rb * 180.0 / 10000.0);

    return return_angle;
}

void Rotate_Servo(ethFrameStr *Msg)
{
    degree=3;
    motor_service_id = xGetServiceID(Msg);

    if (motor_service_id == MOTOR_SERVICE_ID && Msg->Message_Type == REQUEST_NO_RETURN)
    {
        degree = Msg->Payload[0];
        temp_calc = (SERVO_MINIMUM_DUTY + SERVO_EACH_DEGREE * (float)degree);
        R_GPT0->GTCCR[0] = (uint32_t)(Timer_Period * temp_calc);
    }
}



void GPT_Setting()
{
    R_MSTP->MSTPCRD_b.MSTPD5 = 0U; // GPT32EH0 Module Stop State Cancel

    R_GPT0->GTCR_b.MD = 0U;   // GPT32EH0 Count Mode Setting (Saw-wave PWM Mode)
    R_GPT0->GTCR_b.TPCS = 0U; // GPT32EH0 Clock Source Pre-scale Setting (PCLKD/1)

    R_GPT0->GTPR = Timer_Period - 1; // GPT32EH0 Counting Maximum Cycle Setting
    R_GPT0->GTCNT = 0;               // GPT32EH0 Counter Initial Value Setting

    R_GPT0->GTIOR_b.GTIOA = 9U; // Compare Matching Output Control Setting
    R_GPT0->GTIOR_b.OAE = 1U;   // GPIOCA Output Pin Enable

    R_GPT0->GTCCR[0] = (uint32_t)(Timer_Period * SERVO_MINIMUM_DUTY); // GTCCR Initial Setting (Angle = 0[degree])

    R_GPT0->GTCR_b.CST = 1U; // GPT32EH0 Count Start

    return;
}