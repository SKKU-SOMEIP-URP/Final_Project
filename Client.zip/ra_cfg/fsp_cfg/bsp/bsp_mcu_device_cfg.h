/* generated configuration header file - do not edit */
#ifndef BSP_MCU_DEVICE_CFG_H_
#define BSP_MCU_DEVICE_CFG_H_
#define BSP_CFG_MCU_PART_SERIES (6)
#endif /* BSP_MCU_DEVICE_CFG_H_ */
