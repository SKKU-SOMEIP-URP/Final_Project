/* generated configuration header file - do not edit */
#ifndef R_ETHER_PHY_CFG_H_
#define R_ETHER_PHY_CFG_H_
#define ETHER_PHY_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define ETHER_PHY_CFG_USE_PHY (BOARD_PHY_TYPE)
#define ETHER_PHY_CFG_USE_REF_CLK (BOARD_PHY_REF_CLK)
#endif /* R_ETHER_PHY_CFG_H_ */
