#include <hal_data.h>
#include <g_Ethernet.h>
#include <someip_sd.h>
#ifndef FND_LIB_H_
#define FND_LIB_H_


void Segments_Write(int num);
void Segment_Write(int seg_data, int seg_digit);
void FND_write(ethFrameStr *Msg);


/*                      0     1     2     3     4     5     6     7     8     9     - */
const uint8_t SEG[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x27, 0x7F, 0x6F, 0x40};

#endif 