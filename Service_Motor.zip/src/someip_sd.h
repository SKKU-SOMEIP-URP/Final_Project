#ifndef SOMEIP_SD_LIB_H_
#define SOMEIP_SD_LIB_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <hal_data.h>
#include <g_endian.h>
#include <g_Ethernet.h>

/** SOME/IP - Service Discovery **/
#define SD_SERVICE_ID 0xFFFF
#define SD_METHOD_ID 0x8100
#define SD_SESSION_ID 0x0001
#define SD_FLAGS_SIZE 0x0004
#define SD_FLAGS_OFFER 0x80
#define SD_FLAGS_SUBSCRIBE 0x00
#define SD_LENGTH_ARRAY_SIZE 0x0004
#define SD_ENTRY_SIZE 0x0010
#define SD_IPv4_ENDPOINT_SIZE 0x000C
#define SD_IPv4_ENDPOINT_LENGTH 0x0009
#define SD_IPv4_ENDPOINT_TYPE 0x04
#define SD_FLAGS_OFFSET 0x0000
#define SD_LENGTH_OFFSET 0x0004
#define SD_ENTRIES_OFFSET 0x0008

#define ECU_CLIENT_ID 0x7129

#define MOTOR_SERVICE_ID 0x6000
#define ULTRASOUND_SERVICE_ID 0x7000
#define MAX_SERVERS 2 // 최대 서버 수

/** Message Types **/
typedef enum
{
   REQUEST = 0x00,
   REQUEST_NO_RETURN = 0x01,
   NOTIFICATION = 0x02,
   RESPONSE = 0x80,
   ERROR = 0x81,
   TP_REQUEST = 0x20,
   TP_REQUEST_NO_RETURN = 0x21,
   TP_NOTIFICATION = 0x22,
   TP_RESPONSE = 0xA0,
   TP_ERROR = 0xA1
} ENUM_MESSAGE_TYPE;
/** Return Codes **/
typedef enum
{
   E_OK = 0x00,
   E_NOT_OK = 0x01,
   E_UNKNOWN_SERVICE = 0x02,
   E_UNKNOWN_METHOD = 0x03,
   E_NOT_READY = 0x04,
   E_NOT_REACHABLE = 0x05,
   E_TIMEOUT = 0x06,
   E_WRONG_PROTOCOL_VERSION = 0x07,
   E_WRONG_INTERFACE_VERSION = 0x08,
   E_MALFORMED_MESSAGE = 0x09,
   E_WRONG_NMESSAGE_TYPE = 0x0A
} ENUM_RETURN_CODE;
typedef enum
{
   SD_TYPE_FIND = 0x00,
   SD_TYPE_OFFER = 0x01,
   SD_TYPE_REQUEST_SERVICE = 0x02,
   SD_TYPE_REQUEST_SERVICE_ACK = 0x03,
   SD_TYPE_FIND_EVENTGROUP = 0x04,
   SD_TYPE_PUBLISH_EVENTGROUP = 0x05,
   SD_TYPE_SUBSCRIBE = 0x06,
   SD_TYPE_SUBSCRIBE_ACK = 0x07
} ENUM_SERVICE_DISCOVERY_TYPE;

typedef struct _ServiceEntryStr
{
   uint8_t Type;             // Service Entry Type (1byte)
   uint8_t OptionIdx1st;     // Service Entry Option Index 1st (1byte)
   uint8_t OptionIdx2nd;     // Service Entry Option Index 2nd (1byte)
   uint8_t OptionNum1st : 4; // Service Entry Option Number 1st (4bit)
   uint8_t OptionNum2nd : 4; // Service Entry Option Number 2nd (4bit)
   uint16_t ServiceID;       // Service Entry Service ID (2bytes)
   uint16_t InstanceID;      // Service Entry Instance ID (2bytes)
   uint8_t MajorVer;         // Service Entry Major Version (1byte)
   uint8_t TTL[3];           // Service Entry TTL (3bytes)
   uint32_t MinorVer;        // Service Entry Minor Version (4bytes)
} SD_ServiceEntry;

typedef struct _EventgroupEntryStr
{
   uint8_t Type;             // Eventgroup Entry Type (1byte)
   uint8_t OptionIdx1st;     // Eventgroup Entry Option Index 1st (1byte)
   uint8_t OptionIdx2nd;     // Eventgroup Entry Option Index 2nd (1byte)
   uint8_t OptionNum1st : 4; // Eventgroup Entry Option Number 1st (4bit)
   uint8_t OptionNum2nd : 4; // Eventgroup Entry Option Number 2nd (4bit)
   uint16_t ServiceID;       // Eventgroup Entry Service ID (2bytes)
   uint16_t InstanceID;      // Eventgroup Entry Instance ID (2bytes)
   uint8_t MajorVer;         // Eventgroup Entry Major Version (1byte)
   uint8_t TTL[3];           // Eventgroup Entry TTL (3bytes)
   uint16_t Counter;         // Eventgroup Entry Counter (2bytes)
   uint16_t EventgroupID;    // Eventgroup Entry Eventgroup ID (2bytes)
} SD_EventGroupEntry;

typedef struct _IPv4EndpntOptionStr
{
   uint16_t Length;      // Option Length (2bytes)
   uint8_t Type;         // Option Type (1byte)
   uint8_t Reserved_1;   // Reserved (1byte)
   uint8_t IPv4Addr[4];  // IPv4 Address (4bytes)
   uint8_t Reserved_2;   // Reserved (1byte)
   uint8_t L4_Proto;     // L4 Protocol (1byte) 0x11 = UDP, 0x06 = TCP
   uint16_t Port_Number; // Port Number (2bytes)
} SD_IPv4EndpntOption;

void TransTask_SD_Offer(ethFrameStr *Msg, uint16_t Service_ID);
void RecvTask_SD(ethFrameStr *RxMsg, ethFrameStr *TxMsg);
void vMakeOfferMsg(ethFrameStr *Msg, uint16_t Service_ID);
void vMakeSubMsg(ethFrameStr *Msg);
void vMakeStopSubMsg(ethFrameStr *Msg);
void vMakeSubAckMsg(ethFrameStr *Msg);
void vSetSD_Flags(ethFrameStr *Msg, uint8_t Flags);
void vAppendSD_IPv4EndpntOption(ethFrameStr *Msg, SD_IPv4EndpntOption Option, uint32_t Offset);
void vAppendSD_ServiceEntry(ethFrameStr *Msg, SD_ServiceEntry Entry, uint32_t Offset);
void vAppendSD_EventGroupEntry(ethFrameStr *Msg, SD_EventGroupEntry Entry, uint32_t Offset);
uint32_t xGetSD_EntryLength(ethFrameStr *Msg);
void vAppendSD_EventGroupLength(ethFrameStr *Msg, uint32_t Len);
void vAppendSD_OptionLength(ethFrameStr *Msg, uint32_t Len);
void vSetLength(ethFrameStr *Msg, uint32_t val);
void vSetSD_Header(ethFrameStr *Msg);
void vSetLayer2_3_4(ethFrameStr *Msg);
void vSetServiceID(ethFrameStr *Msg, uint16_t val);
void vSetMethodID(ethFrameStr *Msg, uint16_t val);
void vSetClientID(ethFrameStr *Msg, uint16_t val);
void vSetSessionID(ethFrameStr *Msg, uint16_t val);
void vSetProtocolVersion(ethFrameStr *Msg);
void vSetInterfaceVersion(ethFrameStr *Msg);
void vSetMessageType(ethFrameStr *Msg, uint8_t val);
void vSetReturnCode(ethFrameStr *Msg, uint8_t val);
void vSetPayload(ethFrameStr *Msg, uint8_t val);
uint16_t xGetSD_ServiceID(ethFrameStr *RxMSg);

#endif