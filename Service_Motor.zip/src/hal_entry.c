#include <g_DeviceDriver.h>
#include <g_Ethernet.h>
#include <someip_sd.h>
#include <Servo.h>

FSP_CPP_HEADER
void Initial_Setting();
void R_BSP_WarmStart(bsp_warm_start_event_t event);
FSP_CPP_FOOTER

ethFrameStr TxFrameBuffer;          // Set Transmit Ethernet Frame
ethFrameStr RxFrameBuffer;          // Get Receive Ethernet Frame
ethFrameStr RxFrameBuffer_verified; // Get Receive Ethernet Frame
ethFrameStr Msg;
ethFrameStr TxMsg;

uint32_t RxFrameSize = 100; // Length(Size) of Received Ethernet Message
int distance = 0xff;
float time = 0.0;
float time_fall = 0.0;
float time_rise = 0.0;
float duration = 0.0;
int echo = 0;
int LED2 = 0;

// service와 client 코드 각각 수정해야할 parameter
// 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
uint8_t sourceMAC[ETH_MAC_ADDR_SIZE] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};      // Source MAC Address 0x00, 0x11, 0x22, 0x33, 0x44, 0x66
uint8_t sourceIP[ETH_IP_ADDR_SIZE] = {100, 100, 100, 77};                         // Source IP Address
uint8_t destinationMAC[ETH_MAC_ADDR_SIZE] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff}; // Destination MAC Address 0x00, 0x11, 0x22, 0x33, 0x44, 0x77
uint8_t destinationIP[ETH_IP_ADDR_SIZE] = {100, 100, 100, 55};                    // Destination IP Address

uint16_t SDServiceID = 0x6000; // 초음파센서: 0x7000, 서보모터: 0x6000
uint8_t ECU = 0x01;            // Service: 0x01, Client: 0x00

extern uint8_t subscribe;
extern uint16_t service;
extern uint8_t SD_Tx;
extern uint8_t SD_Offer_Tx;

void hal_entry(void)
{
    HW_Initial_Setting();
    Initial_Setting();
    memset(&RxFrameBuffer, 0, sizeof(ethFrameStr));
    memset(&RxFrameBuffer_verified, 0, sizeof(ethFrameStr));

    TransTask_SD_Offer(&Msg, SDServiceID);
}

void R_IRQ_Callback(external_irq_callback_args_t *p_args)
{
    switch (p_args->channel)
    {
    case EXTERNAL_INTERRUPT_11:
        // subscribe = 1; //client 용
        SD_Offer_Tx = 1; // service 용
        break;
    case EXTERNAL_INTERRUPT_12:
        // subscribe = 0; //client 용
        SD_Offer_Tx = 0; // service 용
        break;
    case EXTERNAL_INTERRUPT_13: // 모터
        break;
    case EXTERNAL_INTERRUPT_14: // 초음파

        break;
    }
}

/* Receive Ethernet Frame from PC */
void R_Eth_Callback(ether_callback_args_t *p_args)
{
    R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_10_PIN_08, 1);    // LED1 Pin 끄기
    R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_10_PIN_09, LED2); // 이더넷 인터럽트마다 led toggle
    LED2 = !LED2;
    switch (p_args->event)
    {
    case ETHER_EVENT_INTERRUPT:
        // You must set "RACT" in the Receive Descriptor to 1 after occur Ethernet Handler.
        // If you use "R_ETHER_Read" HAL Function, Receive Descriptor is automatically set.
        R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MILLISECONDS);
        if (R_ETHER_Read(&g_ether0_ctrl, &RxFrameBuffer, &RxFrameSize) == FSP_SUCCESS)
        {
            R_BSP_SoftwareDelay(96, BSP_DELAY_UNITS_MICROSECONDS);
            if (Verify_RxFrameBuffer(&RxFrameBuffer, &RxFrameBuffer_verified))
            {
                Rotate_Servo(&RxFrameBuffer_verified);
                RecvTask_SD(&RxFrameBuffer_verified, &TxMsg);
            }
        }
        break;
    default:
        break;
    }
    return;
}

void R_AGT0_Interrupt(timer_callback_args_t *p_args) // 10us 씩 증가
{
    FSP_PARAMETER_NOT_USED(p_args);
    time = time + (float)0.01;
    if (time >= 200000)
    {
        time = 0;
    }
}

void R_AGT1_Interrupt(timer_callback_args_t *p_args) // 일정 주기 마다 TRIG Pin 활성화
{
    FSP_PARAMETER_NOT_USED(p_args);
    R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_09_PIN_05, 1); // TRIG Pin 활성화
    R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MICROSECONDS);       // 10us 대기
    R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_09_PIN_05, 0); // TRIG Pin 비활성화
}

void R_ECHO_Interrupt(external_irq_callback_args_t *p_args) // ECHO Pin 상태 변화 감지
{
    FSP_PARAMETER_NOT_USED(p_args);

    // R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_09_PIN_06, &state); //906핀으로 echo의 상태를 읽어옴
    if (!echo) // echo가 0이면 rise
    {
        time_rise = time;
        echo = 1;
    }
    else // echo가 1이면 fall
    {
        time_fall = time;
        echo = 0;

        duration = time_fall - time_rise;              // ECHO Pin pulse width 측정
        distance = (int)(duration * 340 / 10.0 / 2.0); // 340m/s, 10us, 2 = 왕복
    }
}

void Initial_Setting()
{
    R_IOPORT_Open(&g_ioport_ctrl, &g_bsp_pin_cfg);

    R_ICU_ExternalIrqOpen(&g_external_irq_echo_ctrl, &g_external_irq_echo_cfg);
    R_ICU_ExternalIrqEnable(&g_external_irq_echo_ctrl);

    R_AGT_Open(&g_timer0_ctrl, &g_timer0_cfg);
    R_AGT_Start(&g_timer0_ctrl);
    R_AGT_Open(&g_timer1_ctrl, &g_timer1_cfg);
    R_AGT_Start(&g_timer1_ctrl);

    R_AGT_Open(&g_timer0_ctrl, &g_timer0_cfg);
    R_AGT_Start(&g_timer0_ctrl);
    R_AGT_Open(&g_timer1_ctrl, &g_timer1_cfg);
    R_AGT_Start(&g_timer1_ctrl);

    GPT_Setting();
}
void R_BSP_WarmStart(bsp_warm_start_event_t event)
{
    if (BSP_WARM_START_RESET == event)
    {
#if BSP_FEATURE_FLASH_LP_VERSION != 0

        /* Enable reading from data flash. */
        R_FACI_LP->DFLCTL = 1U;

        /* Would normally have to wait tDSTOP(6us) for data flash recovery. Placing the enable here, before clock and
         * C runtime initialization, should negate the need for a delay since the initialization will typically take more than 6us. */
#endif
    }

    if (BSP_WARM_START_POST_C == event)
    {
        /* C runtime environment and system clocks are setup. */

        /* Configure pins. */
        R_IOPORT_Open(&g_ioport_ctrl, g_ioport.p_cfg);
    }
}

#if BSP_TZ_SECURE_BUILD

BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable();

/* Trustzone Secure Projects require at least one nonsecure callable function in order to build (Remove this if it is not required to build). */
BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable()
{
}
#endif
