#include <hal_data.h>
#include <someip_sd.h>
#include <g_endian.h>
#include <g_network.h>

#ifndef G_ETHERNET_LIB_H_
#define G_ETHERNET_LIB_H_

////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////// USER DEFINITION AREA (Ethernet Parameters) ////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////

#define ETH_MTU_SIZE 1500 // Ethernet II Frame Maximum Transmission Unit Size

#define VLAN_PRI 0b001         // [15:13] VLAN Priority Code Point (3-bit)
#define VLAN_DEI 0b1           // [12:12] VLAN Drop Eligible Indicator (1-bit)
#define VLAN_ID 0b000000110000 // [11: 0] VLAN Identifier (12-bit)

#define ETH_IP_HEADER_SIZE 20     // Initial Setting (No use IP Header Options)
#define ETH_UDP_HEADER_SIZE 8     // Initial Setting
#define ETH_SOMEIP_HEADER_SIZE 16 // Initial Setting
#define ETH_DSCP_INIT 0b000000
#define ETH_ECN_INIT 0b00

#define ETH_IP_GID 0x0001

#define ETH_TTL_INIT 0x40

////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////

#define STRUCT_SHIFT_SIZE 8
#define STRUCT_SHIFT_SIZE_16BIT 16
#define STRUCT_SHIFT_SIZE_24BIT 24
#define STRUCT_SHIFT_SIZE_32BIT 32
#define FULL_MASK_8BIT 0xFF
#define FULL_MASK_16BIT 0xFFFF
#define FULL_MASK_32BIT 0xFFFFFFFF

#define IP_CHECKSUM_UNIT 2
#define IP_CHECKSUM_DIV 65536

#define ETH_MAC_ADDR_SIZE 6  // Ethernet II Frame MAC Address Size
#define ETH_IP_ADDR_SIZE 4   // Ethernet IP Address Size
#define ETH_TYPE_SIZE 2      // Ethernet II Frame Type Size
#define ETH_VLAN_TAG_COUNT 3 // Ethernet VLAN Tag Component Count

#define ETH_MAC_HEAD_SIZE (ETH_MAC_ADDR_SIZE * 2 + ETH_TYPE_SIZE * 3)
#define ETH_FRAME_SIZE (ETH_MAC_HEAD_SIZE + ETH_MTU_SIZE)

#define ETH_VLAN_TYPE 0x8100
#define ETH_IPv4_TYPE 0x0800

#define ETH_IPV_IPv4 0b0100
#define ETH_IPV_IPv6 0b0110

#define ETH_IHL_5 0b0101
#define ETH_IHL_6 0b0110
#define ETH_IHL_7 0b0111
#define ETH_IHL_8 0b1000

#define ETH_NonFrag 0x00
#define ETH_MulFrag 0x20
#define ETH_FragOffset 0x0000

#define ETH_ICMP_PROT 0x01
#define ETH_IGMP_PROT 0x02
#define ETH_TCP_PROT 0x06
#define ETH_UDP_PROT 0x11

#define ETH_SERVICE_ID 0x1000
#define ETH_METHOD_ID 0x0001
#define ETH_CLIENT_ID 0x0001
#define ETH_SESSION_ID 0x0000
#define ETH_PROTOCOL_VERSION 0x01
#define ETH_INTERFACE_VERSION 0x00
#define ETH_MESSAGE_TYPE 0x01 // request:0x00, response:0x80, request no return:0x01, Notification:0x02
#define ETH_RETURN_CODE 0x00  // OK:0x00, not OK:0x01

#define ETH_SDENTRYARRAYLENGTH 0x00000020

typedef enum _eth_ip_checksum eth_ip_checksum;
typedef struct _ethFrameStr ethFrameStr;

void R_Eth_Initial_Setting();
uint16_t calChecksum(ethFrameStr *Msg);
eth_ip_checksum verChecksum(ethFrameStr *Msg);
void setLayer2(ethFrameStr *Msg, uint8_t *dMAC, uint8_t *sMAC);
void setLayer3(ethFrameStr *Msg, uint8_t *dIP, uint8_t *sIP);
void setLayer4(ethFrameStr *Msg, uint16_t dPort, uint16_t sPort);
void setLayer5(ethFrameStr *Msg);
void setLayer7(ethFrameStr *Msg, uint8_t data);
void setEthFrame(ethFrameStr *Msg, uint8_t *dMAC, uint8_t *sMAC, uint8_t *dIP, uint8_t *sIP, uint8_t data);
int Verify_RxFrameBuffer(ethFrameStr *RxFrameBuffer, ethFrameStr *RxFrameBuffer_verified);
void sendUltrasonicMsg(ethFrameStr *Msg, uint8_t data);
void sendReplyMsg(ethFrameStr *RxMsg, ethFrameStr *TxMsg);
uint16_t xGetServiceID(ethFrameStr * Msg);
void sendServoMotorMsg(ethFrameStr *TxMsg, uint8_t TxAngle);

typedef enum _eth_ip_checksum
{
   correct_checksum = 0,
   wrong_checksum
} eth_ip_checksum;

typedef struct _ethFrameStr
{
   ///////////////////////////////////////////////////////////////////
   /// Support Data-link Layer (OSI-2nd-Layer) (Ethernet II Frame) ///
   ///////////////////////////////////////////////////////////////////

   uint8_t dstMAC[ETH_MAC_ADDR_SIZE]; // Destination MAC Address (6bytes)
   uint8_t srcMAC[ETH_MAC_ADDR_SIZE]; // Source MAC Address (6bytes)
   uint8_t ethType[ETH_TYPE_SIZE];    // EtherType (2bytes)

   ///////////////////////////////////////////////////////////////////////////
   /// Support Network Layer (OSI-3rd-Layer) (Internet Protocol Version 4) ///
   ///////////////////////////////////////////////////////////////////////////

   uint8_t IHL : 4;                 // Internet Protocol Header Length (Unit: Word)
   uint8_t IPV : 4;                 // Internet Protocol Version (4 or 6)
   uint8_t ECN : 2;                 // Explicit Congestion Notification
   uint8_t DSCP : 6;                // Differentiated Services Code Point
   uint8_t TotalLen[2];             // Total Packet Size (Unit: Byte)
   uint8_t GroupID[2];              // Fragmentation Group Identification
   uint8_t fragInfo[2];             // Flags and Fragment Offset
   uint8_t TTL;                     // Time-to-Live of Packet (Prevent routing-loop)
   uint8_t Protocol;                // Upper Layer Protocol Type (TCP[0x06] / UDP[0x11])
   uint8_t ICS[2];                  // IP Header Checksum Value
   uint8_t srcIP[ETH_IP_ADDR_SIZE]; // Source IP Address (4bytes)
   uint8_t dstIP[ETH_IP_ADDR_SIZE]; // Destination IP Address (4bytes)

   ///////////////////////////////////////////////////////////
   /// Support Transport Layer (OSI-4th-Layer) (TCP / UDP) ///
   ///////////////////////////////////////////////////////////

   uint16_t srcPort;        // Source Port Number (2bytes)
   uint16_t dstPort;        // Destination Port Number (2bytes)
   uint8_t UDP_Len[2];      // Length (2bytes)
   uint8_t UDP_Checksum[2]; // Checksum (2bytes)

   ///////////////////////////////////////////////////////////
   /// Support Session Layer (OSI-5th-Layer) (SOME/IP) ///////
   ///////////////////////////////////////////////////////////

   // SOME/IP Header
   uint16_t Service_ID;       // Service ID (2bytes)
   uint16_t Method_ID;        // Method ID (2bytes)
   uint8_t SOMEIP_Length[4];  // SOME/IP Length (4bytes)
   uint16_t Client_ID;        // Client ID (2bytes)
   uint16_t Session_ID;       // Session ID (2bytes)
   uint8_t Protocol_Version;  // Protocol Version (1byte)
   uint8_t Interface_Version; // Interface Version (1byte)
   uint8_t Message_Type;      // Message Type (1byte)
   uint8_t Return_Code;       // Return Code (1byte)

   ///////////////////////////////////////////////////////////
   /// Support Presentation Layer (OSI-6th-Layer) (X) ////////
   ///////////////////////////////////////////////////////////

   ///////////////////////////////////////////////////////////
   /// Support Application Layer (OSI-7th-Layer) (Message) ///
   ///////////////////////////////////////////////////////////

   uint8_t Payload[ETH_MTU_SIZE - ETH_IP_HEADER_SIZE -
                   ETH_UDP_HEADER_SIZE - ETH_SOMEIP_HEADER_SIZE];

} ethFrameStr;

#endif /* G_ETHERNET_LIB_H_ */
